// variables4.rs
// Make me compile! Execute the command `rustlings hint variables4` if you want a hint :)

fn main() {
    let x: i32 = 1;
    println!("Number {}", x);
}
