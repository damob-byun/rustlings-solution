// functions1.rs
// Make me compile! Execute `rustlings hint functions1` for hints :)

fn call_me() {
    println!("I'm called!");
}
fn main() {
    call_me();
}
