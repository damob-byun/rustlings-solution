// variables1.rs
// Make me compile!
// Execute the command `rustlings hint variables1` if you want a hint :)

fn main() {
    let x = 5;
    println!("x has the value {}", x);
}
