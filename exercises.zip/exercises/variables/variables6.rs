// variables6.rs
// Make me compile! Execute the command `rustlings hint variables6` if you want a hint :)

const NUMBER: i32 = 3;
fn main() {
    println!("Number {}", NUMBER);
}
