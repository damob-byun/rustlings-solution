// intro2.rs
// Make the code print a greeting to the world.
// Execute `rustlings hint intro2` for a hint.

fn main() {
    println!("Hello {}!", "world");
}
